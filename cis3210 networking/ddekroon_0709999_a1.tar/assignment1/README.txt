Derek Dekroon
0709999
ddekroon@uoguelph.ca

My program runs by going to the assignment1 directory then typing make, followed by make run.

I was having problems with files already existing making the programs run infinitely, so if you're going to run it more then once type make then make run every time. (I do the clean process whenever you type make). My programs read/write in order so n1>n2>n4>n2>n1>n3>n5>n3>n6>n3>n7>n3>n1>repeat. You can exit the program by typing q.

I really hope this works on your computer, when I submitted it was working 100% but you know how these things are.
