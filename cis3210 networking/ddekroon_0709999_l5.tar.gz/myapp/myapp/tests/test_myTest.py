def test_add():
    assert 1+1 == 2

def test_subtract():
    a = 1
    b = a + 1
    c = b-1
    assert b-a == c
